<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Loan;
use App\Models\LoanPayment; // ✅ asegúrate que exista
use Barryvdh\DomPDF\Facade\Pdf;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\LoansReportExport;
use App\Models\Branch;
use Yajra\DataTables\Facades\DataTables;
use App\Models\Client;
use App\Models\LoanDisbursement;
use App\Models\LoanSchedule;

use Carbon\Carbon;
use DB;


class ReportController extends Controller
{
    public function index()
    {
        $branches = Branch::orderBy('name')->get(['id', 'name']);
        $clients  = Client::orderBy('full_name')->get(['id', 'full_name']); // ✅

        return view('admin.reports.index', compact('branches', 'clients'));
    }

    public function loans(Request $request)
    {
        $query = $this->getLoansQueryWithPaid($request)->orderBy('created_at', 'desc');

        return DataTables::of($query)
            ->addIndexColumn()
            ->addColumn('client', fn($loan) => $loan->client->full_name ?? '—')
            ->editColumn('created_at', fn($loan) => optional($loan->created_at)->format('Y-m-d'))

            ->addColumn('paid_total', fn($loan) => 'S/ ' . number_format((float)($loan->paid_total ?? 0), 2))
            ->addColumn('capital_total', fn($loan) => 'S/ ' . number_format((float)($loan->capital_total ?? 0), 2))
            ->addColumn('interest_total', fn($loan) => 'S/ ' . number_format((float)($loan->interest_total ?? 0), 2))
            ->addColumn('installments_paid', fn($loan) => (int)($loan->installments_paid ?? 0))

            ->addColumn('remaining', function ($loan) {
                $remaining = max(0, ((float)$loan->total_payable - (float)($loan->paid_total ?? 0)));
                return 'S/ ' . number_format($remaining, 2);
            })

            ->editColumn('amount', fn($loan) => 'S/ ' . number_format((float)$loan->amount, 2))
            ->editColumn('total_payable', fn($loan) => 'S/ ' . number_format((float)$loan->total_payable, 2))

            ->editColumn('status', function ($loan) {
                $map = [
                    'pending'   => ['badge' => 'warning', 'label' => 'Pendiente'],
                    'approved'  => ['badge' => 'primary', 'label' => 'Aprobado'],
                    'disbursed' => ['badge' => 'success', 'label' => 'Desembolsado'],
                    'finished'  => ['badge' => 'dark', 'label' => 'Finalizado'],
                    'canceled'  => ['badge' => 'secondary', 'label' => 'Cancelado'],
                ];
                $info = $map[$loan->status] ?? ['badge' => 'secondary', 'label' => $loan->status];
                return "<span class='badge badge-{$info['badge']}'>{$info['label']}</span>";
            })
            ->rawColumns(['status'])
            ->make(true);
    }


    public function exportLoansPdf(Request $request)
    {
        // ✅ Traemos préstamos con total pagado en el rango
        $loans = $this->getLoansQueryWithPaid($request)
            ->orderBy('created_at', 'desc')
            ->get();

        // ✅ KPIs
        $totalPrestado  = (float) $loans->sum('amount');
        $totalAPagar    = (float) $loans->sum('total_payable');
        $totalRecuperado = (float) $loans->sum('paid_total');

        $gananciaEsperada = max(0, $totalAPagar - $totalPrestado);
        $pendienteTotal   = max(0, $totalAPagar - $totalRecuperado);

        $recoveryRate = $totalPrestado > 0
            ? round(($totalRecuperado / $totalPrestado) * 100, 2)
            : 0;

        $branchName = 'Todas';

        if ($request->branch_id) {
            $branchName = Branch::where('id', $request->branch_id)->value('name') ?? '—';
        }

        $clientName = 'Todos';
        if ($request->client_id) {
            $clientName = \App\Models\Client::where('id', $request->client_id)->value('full_name') ?? '—';
        }

        $filters = [
            'date_from'   => $request->date_from,
            'date_to'     => $request->date_to,
            'branch_name' => $branchName,
            'client_name' => $clientName, // ✅
        ];

        $summary = compact(
            'totalPrestado',
            'totalAPagar',
            'totalRecuperado',
            'gananciaEsperada',
            'pendienteTotal',
            'recoveryRate'
        );

        $pdf = Pdf::loadView('admin.reports.pdf.loans', compact('loans', 'summary', 'filters'))
            ->setPaper('A4', 'landscape');

        return $pdf->stream('reporte_consolidado_prestamos.pdf');
    }

    public function exportLoansExcel(Request $request)
    {
        return Excel::download(
            new LoansReportExport($request),
            'reporte_prestamos.xlsx'
        );
    }

    /**
     * ✅ Query con total pagado en el rango (por préstamo)
     */
    /**
     * ✅ Query con totales por préstamo EN EL RANGO:
     * - paid_total (monto)
     * - capital_total
     * - interest_total
     * - installments_paid (cuotas pagadas en el rango, usando paid_at de loan_schedules)
     */
    private function getLoansQueryWithPaid(Request $request)
    {
        $dateFrom = $request->date_from;
        $dateTo   = $request->date_to;

        return Loan::with(['client', 'branch'])

            ->when($request->branch_id, fn($q) => $q->where('branch_id', $request->branch_id))
            ->when($request->client_id, fn($q) => $q->where('client_id', $request->client_id))
            ->when($dateFrom, fn($q) => $q->whereDate('created_at', '>=', $dateFrom))
            ->when($dateTo, fn($q) => $q->whereDate('created_at', '<=', $dateTo))
            /* ->when($request->branch_id, fn($q) => $q->where('branch_id', $request->branch_id))
            ->when($request->client_id, fn($q) => $q->where('client_id', $request->client_id)) */

            /*  ->when($dateFrom, fn($q) => $q->whereDate('created_at', '>=', $dateFrom))
            ->when($dateTo,   fn($q) => $q->whereDate('created_at', '<=', $dateTo)) */


            ->when($dateFrom, fn($qq) => $qq->whereDate('created_at', '>=', $dateFrom))
            ->when($dateTo,   fn($qq) => $qq->whereDate('created_at', '<=', $dateTo))

            ->addSelect([

                // ✅ Total recuperado (monto pagado) en el rango
                'paid_total' => LoanPayment::query()
                    ->selectRaw('COALESCE(SUM(loan_payments.amount),0)')
                    ->whereColumn('loan_payments.loan_id', 'loans.id')
                    ->where('loan_payments.status', 'completed')
                    ->when($dateFrom, fn($qq) => $qq->whereDate('loan_payments.payment_date', '>=', $dateFrom))
                    ->when($dateTo,   fn($qq) => $qq->whereDate('loan_payments.payment_date', '<=', $dateTo)),
                // ✅ Capital pagado en el rango
                'capital_total' => LoanPayment::query()
                    ->selectRaw('COALESCE(SUM(loan_payments.capital),0)')
                    ->whereColumn('loan_payments.loan_id', 'loans.id')
                    ->where('loan_payments.status', 'completed')
                    ->when($dateFrom, fn($qq) => $qq->whereDate('loan_payments.payment_date', '>=', $dateFrom))
                    ->when($dateTo,   fn($qq) => $qq->whereDate('loan_payments.payment_date', '<=', $dateTo)),


                // ✅ Interés pagado en el rango
                'interest_total' => LoanPayment::query()
                    ->selectRaw('COALESCE(SUM(loan_payments.interest),0)')
                    ->whereColumn('loan_payments.loan_id', 'loans.id')
                    ->where('loan_payments.status', 'completed')
                    ->when($dateFrom, fn($qq) => $qq->whereDate('loan_payments.payment_date', '>=', $dateFrom))
                    ->when($dateTo,   fn($qq) => $qq->whereDate('loan_payments.payment_date', '<=', $dateTo)),


                // ✅ # cuotas pagadas en el rango (cuotas que se marcaron PAID con paid_at dentro del rango)
                'installments_paid' => \App\Models\LoanSchedule::query()
                    ->selectRaw('COALESCE(COUNT(*),0)')
                    ->whereColumn('loan_id', 'loans.id')
                    ->where('status', 'paid')
                    ->when($dateFrom, fn($qq) => $qq->whereDate('paid_at', '>=', $dateFrom))
                    ->when($dateTo,   fn($qq) => $qq->whereDate('paid_at', '<=', $dateTo)),
            ]);
    }



    public function payments(Request $request)
    {
        $query = LoanPayment::with(['loan.client', 'branch', 'user'])
            ->when($request->branch_id, fn($q) => $q->where('branch_id', $request->branch_id))
            ->when($request->client_id, function ($q) use ($request) { // ✅
                $q->whereHas('loan', fn($qq) => $qq->where('client_id', $request->client_id));
            })
            ->when($request->date_from, fn($q) => $q->whereDate('payment_date', '>=', $request->date_from))
            ->when($request->date_to, fn($q) => $q->whereDate('payment_date', '<=', $request->date_to))
            ->orderBy('id', 'desc');

        return DataTables::of($query)
            ->addIndexColumn()
            ->addColumn('loan_code', fn($p) => optional($p->loan)->loan_code ?? '—')
            ->addColumn('client_name', fn($p) => optional(optional($p->loan)->client)->full_name ?? '—')
            ->addColumn('method', fn($p) => $p->method ? ucfirst($p->method) : '—')
            ->editColumn('amount', fn($p) => 'S/ ' . number_format($p->amount, 2))
            ->editColumn('payment_date', fn($p) => $p->payment_date ? $p->payment_date->format('Y-m-d') : '—')
            ->make(true);
    }

    public function recovery(Request $request)
    {
        $branchId = $request->branch_id;

        $loansQ = Loan::query()
            ->when($branchId, fn($q) => $q->where('branch_id', $branchId))
            ->when($request->client_id, fn($q) => $q->where('client_id', $request->client_id)) // ✅
            ->when($request->date_from, fn($q) => $q->whereDate('created_at', '>=', $request->date_from))
            ->when($request->date_to, fn($q) => $q->whereDate('created_at', '<=', $request->date_to));

        $totalDisbursed = (float) $loansQ->sum('amount');

        $paidQ = LoanPayment::query()
            ->where('status', 'completed')
            ->when($branchId, fn($q) => $q->where('branch_id', $branchId))
            ->when($request->client_id, function ($q) use ($request) { // ✅
                $q->whereHas('loan', fn($qq) => $qq->where('client_id', $request->client_id));
            })
            ->when($request->date_from, fn($q) => $q->whereDate('payment_date', '>=', $request->date_from))
            ->when($request->date_to, fn($q) => $q->whereDate('payment_date', '<=', $request->date_to));

        $totalPaid = (float) $paidQ->sum('amount');

        $rate = $totalDisbursed > 0 ? round(($totalPaid / $totalDisbursed) * 100, 2) : 0;

        return response()->json([
            'status' => 'success',
            'data' => [
                'total_disbursed' => round($totalDisbursed, 2),
                'total_paid' => round($totalPaid, 2),
                'recovery_rate' => $rate,
            ]
        ]);
    }


    public function operations(Request $request)
    {
        /*
    |---------------------------------
    | INGRESOS (pagos)
    |---------------------------------
    */
        $payments = LoanPayment::query()
            ->where('status', 'completed')
            ->when($request->branch_id, fn($q) => $q->where('branch_id', $request->branch_id))
            ->when($request->date_from, fn($q) => $q->whereDate('payment_date', '>=', $request->date_from))
            ->when($request->date_to, fn($q) => $q->whereDate('payment_date', '<=', $request->date_to))
            ->get();

        /*
    |---------------------------------
    | SALIDAS (préstamos colocados)
    |---------------------------------
    */
        $loans = Loan::query()
            ->whereIn('status', ['disbursed', 'finished'])
            ->when($request->branch_id, fn($q) => $q->where('branch_id', $request->branch_id))
            ->when($request->date_from, fn($q) => $q->whereDate('created_at', '>=', $request->date_from))
            ->when($request->date_to, fn($q) => $q->whereDate('created_at', '<=', $request->date_to))
            ->get();

        $capitalRevolvente = $loans
            ->where('term_months', 1)
            ->sum('amount');

        $capitalCuotas = $loans
            ->where('term_months', '>', 1)
            ->sum('amount');


        $ingresosCaja = $payments->sum('amount') - $payments->sum('cash_change');

        $salidasCaja = $capitalRevolvente + $capitalCuotas;

        $saldoCaja = $ingresosCaja - $salidasCaja;

        return response()->json([
            // INGRESOS
            'monto_cobrado'      => round($payments->sum('amount'), 2),
            'capital_recuperado' => round($payments->sum('capital'), 2),
            'intereses_cobrados' => round($payments->sum('interest'), 2),
            'vuelto_cliente'     => round($payments->sum('cash_change'), 2),

            // SALIDAS
            'capital_revolvente' => round($capitalRevolvente, 2),
            'capital_cuotas'     => round($capitalCuotas, 2),

            //caja
            'saldo_caja' => round($saldoCaja, 2),
        ]);
    }


    public function commercial(Request $request)
    {
        $from = $request->date_from;
        $to   = $request->date_to;

        $loans = Loan::query()
            ->whereIn('status', ['disbursed', 'finished']) // ✅
            ->when($request->branch_id, fn($q) => $q->where('branch_id', $request->branch_id))
            ->when($request->client_id, fn($q) => $q->where('client_id', $request->client_id))
            ->when($from, fn($q) => $q->whereDate('disbursement_date', '>=', $from))
            ->when($to, fn($q) => $q->whereDate('disbursement_date', '<=', $to))
            ->get();

        $loanIds = $loans->pluck('id');

        /*
    |--------------------------------------------------------------------------
    | 1️⃣ CAPITAL REVOLVENTE (1 cuota)
    |--------------------------------------------------------------------------
    */
        $revLoans = $loans->where('term_months', 1);

        $revCapital = $revLoans->sum('amount');
        $revInterest = $revLoans->sum(fn($l) => $l->total_payable - $l->amount);

        /*
    |--------------------------------------------------------------------------
    | 2️⃣ CAPITAL EN CUOTAS (>1)
    |--------------------------------------------------------------------------
    */
        $cuoLoans = $loans->where('term_months', '>', 1);

        $cuoCapital = $cuoLoans->sum('amount');
        $cuoInterest = $cuoLoans->sum(fn($l) => $l->total_payable - $l->amount);

        /*
    |--------------------------------------------------------------------------
    | 3️⃣ CAPITAL VENCIDO (SOLO CUOTAS VENCIDAS)
    |--------------------------------------------------------------------------
    */
        $vencidoCapital = LoanSchedule::whereIn('loan_id', $loanIds)
            ->where('status', 'pending')
            ->whereDate('due_date', '<', now())
            ->sum('amortization');

        $vencidoInterest = LoanSchedule::whereIn('loan_id', $loanIds)
            ->where('status', 'pending')
            ->whereDate('due_date', '<', now())
            ->sum('interest');

        return response()->json([
            'revolvente' => [
                'capital'  => round($revCapital, 2),
                'interest' => round($revInterest, 2),
            ],
            'cuotas' => [
                'capital'  => round($cuoCapital, 2),
                'interest' => round($cuoInterest, 2),
            ],
            'vencido' => [
                'capital'  => round($vencidoCapital, 2),
                'interest' => round($vencidoInterest, 2),
            ],
        ]);
    }


    // ReportController.php
    private function getCommercialData(Request $request): array
    {
        $from = $request->date_from;
        $to   = $request->date_to;

        $loans = Loan::query()
            ->with('client')
            ->where('status', 'disbursed')
            ->when($request->branch_id, fn($q) => $q->where('branch_id', $request->branch_id))
            ->when($request->client_id, fn($q) => $q->where('client_id', $request->client_id))
            ->when($from, fn($q) => $q->whereDate('created_at', '>=', $from))
            ->when($to, fn($q) => $q->whereDate('created_at', '<=', $to))
            ->get();

        $loanIds = $loans->pluck('id');

        // 1️⃣ Revolvente
        $revLoans = $loans->where('term_months', 1);
        $revCapital = $revLoans->sum('amount');
        $revInterest = $revLoans->sum(fn($l) => $l->total_payable - $l->amount);

        // 2️⃣ Cuotas
        $cuoLoans = $loans->where('term_months', '>', 1);
        $cuoCapital = $cuoLoans->sum('amount');
        $cuoInterest = $cuoLoans->sum(fn($l) => $l->total_payable - $l->amount);

        // 3️⃣ Vencido
        $vencidoCapital = LoanSchedule::whereIn('loan_id', $loanIds)
            ->where('status', 'pending')
            ->whereDate('due_date', '<', now())
            ->sum('capital');

        $vencidoInterest = LoanSchedule::whereIn('loan_id', $loanIds)
            ->where('status', 'pending')
            ->whereDate('due_date', '<', now())
            ->sum('interest');

        return compact(
            'loans',
            'revCapital',
            'revInterest',
            'cuoCapital',
            'cuoInterest',
            'vencidoCapital',
            'vencidoInterest'
        );
    }



    public function exportCommercialPdf(Request $request)
    {
        $from = $request->date_from;
        $to   = $request->date_to;

        $loans = Loan::with('client')
            ->whereIn('status', ['disbursed', 'finished'])
            ->when($request->branch_id, fn($q) => $q->where('branch_id', $request->branch_id))
            ->when($request->client_id, fn($q) => $q->where('client_id', $request->client_id))
            ->when($from, fn($q) => $q->whereDate('disbursement_date', '>=', $from))
            ->when($to, fn($q) => $q->whereDate('disbursement_date', '<=', $to))
            ->get();

        $loanIds = $loans->pluck('id');

        // 🔹 Capital Revolvente
        $revLoans = $loans->where('term_months', 1);
        $revCapital = $revLoans->sum('amount');
        $revInterest = $revLoans->sum(fn($l) => $l->total_payable - $l->amount);

        // 🔹 Capital en Cuotas
        $cuoLoans = $loans->where('term_months', '>', 1);
        $cuoCapital = $cuoLoans->sum('amount');
        $cuoInterest = $cuoLoans->sum(fn($l) => $l->total_payable - $l->amount);

        // 🔹 Capital vencido
        $vencidoCapital = LoanSchedule::whereIn('loan_id', $loanIds)
            ->where('status', 'pending')
            ->whereDate('due_date', '<', now())
            ->sum('amortization');

        $vencidoInterest = LoanSchedule::whereIn('loan_id', $loanIds)
            ->where('status', 'pending')
            ->whereDate('due_date', '<', now())
            ->sum('interest');

        $filters = [
            'date_from' => $from,
            'date_to'   => $to,
        ];

        $pdf = Pdf::loadView(
            'admin.reports.pdf.commercial',
            compact(
                'loans',
                'revCapital',
                'revInterest',
                'cuoCapital',
                'cuoInterest',
                'vencidoCapital',
                'vencidoInterest',
                'filters'
            )
        )->setPaper('A4', 'portrait');

        return $pdf->stream('reporte_comercial.pdf');
    }




    public function operationsPdf(Request $request)
    {
        // INGRESOS
        $payments = LoanPayment::query()
            ->where('status', 'completed')
            ->when($request->branch_id, fn($q) => $q->where('branch_id', $request->branch_id))
            ->when($request->date_from, fn($q) => $q->whereDate('payment_date', '>=', $request->date_from))
            ->when($request->date_to, fn($q) => $q->whereDate('payment_date', '<=', $request->date_to))
            ->get();

        // SALIDAS
        $loans = Loan::query()
            ->whereIn('status', ['disbursed', 'finished'])
            ->when($request->branch_id, fn($q) => $q->where('branch_id', $request->branch_id))
            ->when($request->date_from, fn($q) => $q->whereDate('created_at', '>=', $request->date_from))
            ->when($request->date_to, fn($q) => $q->whereDate('created_at', '<=', $request->date_to))
            ->get();

        $capitalRevolvente = $loans->where('term_months', 1)->sum('amount');
        $capitalCuotas     = $loans->where('term_months', '>', 1)->sum('amount');

        $montoCobrado  = $payments->sum('amount');
        $vueltoCliente = $payments->sum('cash_change');

        $ingresosCaja = $montoCobrado - $vueltoCliente;
        $salidasCaja  = $capitalRevolvente + $capitalCuotas;
        $saldoCaja    = $ingresosCaja - $salidasCaja;

        $pdf = Pdf::loadView('admin.reports.pdf.operations', [
            'filters' => $request->all(),

            // INGRESOS
            'montoCobrado'      => $montoCobrado,
            'capitalRecuperado' => $payments->sum('capital'),
            'interesesCobrados' => $payments->sum('interest'),
            'vueltoCliente'     => $vueltoCliente,

            // SALIDAS
            'capitalRevolvente' => $capitalRevolvente,
            'capitalCuotas'     => $capitalCuotas,

            // RESUMEN
            'totalIngresos' => $ingresosCaja,
            'totalSalidas'  => $salidasCaja,
            'saldoCaja'     => $saldoCaja,
        ]);

        return $pdf->stream('reporte-operaciones.pdf');
    }



    public function cashPdf(Request $request)
    {
        /*
    |---------------------------------
    | INGRESOS
    |---------------------------------
    */
        $payments = LoanPayment::query()
            ->where('status', 'completed')
            ->when($request->branch_id, fn($q) => $q->where('branch_id', $request->branch_id))
            ->when($request->date_from, fn($q) => $q->whereDate('payment_date', '>=', $request->date_from))
            ->when($request->date_to, fn($q) => $q->whereDate('payment_date', '<=', $request->date_to))
            ->get();

        $montoApertura = 0; // si luego lo manejas desde tabla, aquí se cambia
        $montoCobrado  = $payments->sum('amount');
        $vueltoCliente = $payments->sum('cash_change');

        $totalIngresos = $montoApertura + ($montoCobrado - $vueltoCliente);

        /*
    |---------------------------------
    | SALIDAS
    |---------------------------------
    */
        $loans = Loan::query()
            ->whereIn('status', ['disbursed', 'finished'])
            ->when($request->branch_id, fn($q) => $q->where('branch_id', $request->branch_id))
            ->when($request->date_from, fn($q) => $q->whereDate('created_at', '>=', $request->date_from))
            ->when($request->date_to, fn($q) => $q->whereDate('created_at', '<=', $request->date_to))
            ->get();

        $capitalRevolvente = $loans->where('term_months', 1)->sum('amount');
        $capitalCuotas     = $loans->where('term_months', '>', 1)->sum('amount');
        $otrasSalidas      = 0;

        $totalSalidas = $vueltoCliente + $capitalRevolvente + $capitalCuotas + $otrasSalidas;

        /*
    |---------------------------------
    | SALDO FINAL
    |---------------------------------
    */
        $saldoCaja = $totalIngresos - $totalSalidas;

        $pdf = Pdf::loadView('admin.reports.pdf.cash', [
            'filters' => $request->all(),

            // INGRESOS
            'montoApertura' => $montoApertura,
            'montoCobrado'  => $montoCobrado,
            'totalIngresos' => $totalIngresos,

            // SALIDAS
            'vueltoCliente'    => $vueltoCliente,
            'capitalRevolvente' => $capitalRevolvente,
            'capitalCuotas'    => $capitalCuotas,
            'otrasSalidas'     => $otrasSalidas,
            'totalSalidas'     => $totalSalidas,

            // SALDO
            'saldoCaja' => $saldoCaja,
        ])->setPaper('A4');

        return $pdf->stream('cuadre_caja.pdf');
    }
}
