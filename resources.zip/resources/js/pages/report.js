/* ======================================================
   REPORTES - PRÉSTAMOS
   ====================================================== */

var divLoading = document.getElementById('divLoading');
let tableReportLoans;

document.addEventListener('DOMContentLoaded', function () {

    // ============================
    // CSRF PARA AJAX
    // ============================
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    // ============================
    // DATATABLE PRÉSTAMOS
    // ============================
    initLoansReportTable();

    // ============================
    // APLICAR FILTROS
    // ============================
    $('#btnApplyFilters').on('click', function () {
        if (tableReportLoans) {
            tableReportLoans.ajax.reload();
        }
    });

    // ============================
    // EXPORTACIONES
    // ============================
    $('#btnLoansPdf').on('click', function (e) {
        e.preventDefault();
        window.open(buildUrl(window.routes.loansPdf, getReportParams()), '_blank');
    });

    $('#btnLoansExcel').on('click', function (e) {
        e.preventDefault();
        window.location.href = buildUrl(window.routes.loansExcel, getReportParams());
    });
});


/* ======================================================
   INIT DATATABLE
   ====================================================== */
function initLoansReportTable() {

    tableReportLoans = $('#tableReportLoans').DataTable({
        processing: true,
        serverSide: true,
        responsive: true,
        autoWidth: false,
        destroy: true,

        ajax: {
            url: window.routes.reportsLoans,
            type: 'GET',
            data: function (d) {
                const p = getReportParams();
                d.date_from = p.date_from;
                d.date_to = p.date_to;
                d.branch_id = p.branch_id;
                d.client_id = p.client_id; // ✅
            },
            error: function (xhr) {
                console.error('Error DataTable Reportes', xhr.responseText);
            }
        },

        columns: [
            { data: 'DT_RowIndex', orderable: false, searchable: false },
            { data: 'loan_code', name: 'loan_code' },
            { data: 'client', name: 'client.full_name' },
            { data: 'created_at', name: 'created_at' },
            { data: 'amount', name: 'amount' },
            { data: 'total_payable', name: 'total_payable' },

            // ✅ NUEVO (préstamos)
            { data: 'paid_total', orderable: false, searchable: false },
            { data: 'capital_total', orderable: false, searchable: false },
            { data: 'interest_total', orderable: false, searchable: false },
            { data: 'installments_paid', orderable: false, searchable: false },
            { data: 'remaining', orderable: false, searchable: false },

            { data: 'status', orderable: false, searchable: false }
        ],


        dom: `
            <'row mb-2'
                <'col-sm-12 col-md-6'l>
                <'col-sm-12 col-md-6 text-end'f>
            >
            <'row'
                <'col-sm-12'tr>
            >
            <'row mt-2'
                <'col-sm-12 col-md-5'i>
                <'col-sm-12 col-md-7 d-flex justify-content-end'p>
            >
        `,

        language: {
            url: "/vendor/datatables/js/i18n/es-ES.json"
        },

        preDrawCallback: function () {
            divLoading && divLoading.classList.remove('d-none');
        },

        drawCallback: function () {
            divLoading && divLoading.classList.add('d-none');
        }
    });
}


/* ======================================================
   HELPERS
   ====================================================== */
function getReportParams() {
    return {
        date_from: $('#date_from').val(),
        date_to: $('#date_to').val(),
        branch_id: $('#branch_id').val(),
        client_id: $('#client_id').val(), // ✅ nuevo
    };
}

function buildUrl(url, params) {
    const q = new URLSearchParams(params).toString();
    return q ? `${url}?${q}` : url;
}
/*  */

let dtPayments = null;

$('a[data-toggle="tab"][href="#panel-payments"]').on('shown.bs.tab', function () {
    if (dtPayments) return;

    dtPayments = $('#tableReportPayments').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: window.routes.reportsPayments,
            data: function (d) {
                d.date_from = $('#date_from').val();
                d.date_to = $('#date_to').val();
                d.branch_id = $('#branch_id').val();
            }
        },
        columns: [
            { data: 'DT_RowIndex', orderable: false, searchable: false },
            { data: 'payment_code' },
            { data: 'loan_code' },
            { data: 'client_name' },
            { data: 'payment_date' },
            { data: 'amount' },
            { data: 'method' },
            { data: 'status' },
        ]
    });
});

function loadRecovery() {
    $.get(window.routes.reportsRecovery, {
        date_from: $('#date_from').val(),
        date_to: $('#date_to').val(),
        branch_id: $('#branch_id').val(),
        client_id: $('#client_id').val(), // ✅
    }).done(resp => {
        if (!resp || resp.status !== 'success') return;
        $('#kpi_total_disbursed').text('S/ ' + Number(resp.data.total_disbursed).toFixed(2));
        $('#kpi_total_paid').text('S/ ' + Number(resp.data.total_paid).toFixed(2));
        $('#kpi_recovery_rate').text(resp.data.recovery_rate + '%');
    });
}

$('a[data-toggle="tab"][href="#panel-recovery"]').on('shown.bs.tab', loadRecovery);
$('#btnApplyFilters').on('click', function () {
    if (dtPayments) dtPayments.ajax.reload();
    loadRecovery();
});

