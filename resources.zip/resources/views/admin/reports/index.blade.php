@extends('adminlte::page')
@section('plugins.Datatables', true)
@section('plugins.DatatablesPlugins', true)


@section('title', 'Reportes')

@section('content_header')
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h1 class="mb-0">📊 Reportes</h1>
            <small class="text-muted">Préstamos · Pagos · Recuperación</small>
        </div>
    </div>
@stop

@section('content')

    {{-- FILTROS --}}
    <div class="card shadow-sm">
        <div class="card-body">

            <form id="reportFilters" class="row">

                <div class="col-md-3">
                    <label class="small font-weight-bold text-secondary">Desde</label>
                    <input type="date" class="form-control form-control-sm" id="date_from" name="date_from">
                </div>

                <div class="col-md-3">
                    <label class="small font-weight-bold text-secondary">Hasta</label>
                    <input type="date" class="form-control form-control-sm" id="date_to" name="date_to">
                </div>

                <div class="col-md-3">
                    <label class="small font-weight-bold text-secondary">Sucursal</label>
                    <select class="form-control form-control-sm" id="branch_id" name="branch_id">
                        <option value="">Todas</option>
                        @foreach ($branches as $b)
                            <option value="{{ $b->id }}">{{ $b->name }}</option>
                        @endforeach
                    </select>
                </div>

                {{-- ✅ NUEVO: CLIENTE --}}
                <div class="col-md-3">
                    <label class="small font-weight-bold text-secondary">Cliente</label>
                    <select class="form-control form-control-sm" id="client_id" name="client_id">
                        <option value="">Todos</option>
                        @foreach ($clients as $c)
                            <option value="{{ $c->id }}">{{ $c->full_name }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-12 mt-2 d-flex justify-content-end">
                    <button type="button" class="btn btn-primary btn-sm" id="btnApplyFilters">
                        <i class="fas fa-filter mr-1"></i> Aplicar filtros
                    </button>
                </div>

            </form>


        </div>
    </div>

    {{-- TABS --}}
    <div class="card shadow-sm mt-3">
        <div class="card-header p-0">
            <ul class="nav nav-tabs" id="reportTabs" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="tab-loans" data-toggle="tab" href="#panel-loans" role="tab">
                        <i class="fas fa-hand-holding-usd mr-1"></i> Préstamos
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" id="tab-payments" data-toggle="tab" href="#panel-payments" role="tab">
                        <i class="fas fa-cash-register mr-1"></i> Pagos
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" id="tab-recovery" data-toggle="tab" href="#panel-recovery" role="tab">
                        <i class="fas fa-chart-line mr-1"></i> Recuperación
                    </a>
                </li>
            </ul>
        </div>

        <div class="card-body">
            <div class="tab-content">

                {{-- PANEL: PRÉSTAMOS --}}
                <div class="tab-pane fade show active" id="panel-loans" role="tabpanel">

                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div class="text-muted small">
                            Reporte de préstamos colocados en el rango
                        </div>

                        <div class="btn-group">
                            <a href="#" class="btn btn-outline-danger btn-sm" id="btnLoansPdf">
                                <i class="fas fa-file-pdf mr-1"></i> PDF
                            </a>
                            <a href="#" class="btn btn-outline-success btn-sm" id="btnLoansExcel">
                                <i class="fas fa-file-excel mr-1"></i> Excel
                            </a>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-sm w-100" id="tableReportLoans">
                            <thead class="thead-light">
                                <tr>
                                    <th>#</th>
                                    <th>Código</th>
                                    <th>Cliente</th>
                                    <th>Fecha</th>
                                    <th>Monto</th>
                                    <th>Total a pagar</th>
                                    <th>Estado</th>
                                    <th>Recuperado</th>
                                    <th>Capital</th>
                                    <th>Interés</th>
                                    <th># Cuotas</th>
                                    <th>Pendiente</th>

                                </tr>
                            </thead>
                        </table>
                    </div>

                </div>

                {{-- PANEL: PAGOS --}}
                <div class="tab-pane fade" id="panel-payments" role="tabpanel">

                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <div class="text-muted small">
                            Reporte de pagos registrados en el rango
                        </div>

                        <div class="btn-group">
                            <a href="#" class="btn btn-outline-danger btn-sm" id="btnPaymentsPdf">
                                <i class="fas fa-file-pdf mr-1"></i> PDF
                            </a>
                            <a href="#" class="btn btn-outline-success btn-sm" id="btnPaymentsExcel">
                                <i class="fas fa-file-excel mr-1"></i> Excel
                            </a>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-sm w-100" id="tableReportPayments">
                            <thead class="thead-light">
                                <tr>
                                    <th>#</th>
                                    <th>Código pago</th>
                                    <th>Préstamo</th>
                                    <th>Cliente</th>
                                    <th>Fecha</th>
                                    <th>Monto</th>
                                    <th>Método</th>
                                    <th>Estado</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                </div>

                {{-- PANEL: RECUPERACIÓN (Resumen / KPIs) --}}
                <div class="tab-pane fade" id="panel-recovery" role="tabpanel">

                    <div class="row">

                        <div class="col-md-4">
                            <div class="small-box bg-info">
                                <div class="inner">
                                    <h4 id="kpi_total_disbursed">S/ 0.00</h4>
                                    <p>Total prestado</p>
                                </div>
                                <div class="icon"><i class="fas fa-hand-holding-usd"></i></div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="small-box bg-success">
                                <div class="inner">
                                    <h4 id="kpi_total_paid">S/ 0.00</h4>
                                    <p>Total recuperado</p>
                                </div>
                                <div class="icon"><i class="fas fa-cash-register"></i></div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="small-box bg-warning">
                                <div class="inner">
                                    <h4 id="kpi_recovery_rate">0%</h4>
                                    <p>% Recuperación</p>
                                </div>
                                <div class="icon"><i class="fas fa-chart-line"></i></div>
                            </div>
                        </div>

                    </div>

                    <div class="text-muted small">
                        (Aquí luego sacamos cálculos por rango: total prestado vs total pagado, pendientes, etc.)
                    </div>

                </div>

            </div>
        </div>
    </div>

@stop

@push('js')
    <script>
        window.routes = window.routes || {};
        window.routes.reportsLoans = "{{ route('admin.reports.loans') }}";
        window.routes.loansPdf = "{{ route('admin.reports.loans.pdf') }}";
        window.routes.loansExcel = "{{ route('admin.reports.loans.excel') }}";


        // ✅ FALTABAN:
        window.routes.reportsPayments = "{{ route('admin.reports.payments') }}";
        window.routes.reportsRecovery = "{{ route('admin.reports.recovery') }}";
    </script>

    @vite(['resources/js/pages/report.js'])
@endpush
